drop table structure;
drop table chain;
drop table residue;
drop table atom;

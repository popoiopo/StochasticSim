DROP TABLE Person;


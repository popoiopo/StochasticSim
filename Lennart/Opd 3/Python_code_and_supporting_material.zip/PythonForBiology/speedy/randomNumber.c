#include "randomNumber.h"

#include <stdio.h>
#include <stdlib.h>

double randomNumber()
{
  return drand48();
}

#ifndef _incl_somap
#define _incl_somap

extern double ***selfOrganisingMap(double **inputs, int ninputs, int depth,
	int nrows, int ncols, double **spread, int width, int height, int nsteps);

#endif /* _incl_somap */

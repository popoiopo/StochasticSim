delete from structure;
delete from chain;
delete from residue;
delete from atom;


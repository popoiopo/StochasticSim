#ifndef _incl_randomNumber
#define _incl_randomNumber

extern double randomNumber();

#endif /* _incl_randomNumber */
